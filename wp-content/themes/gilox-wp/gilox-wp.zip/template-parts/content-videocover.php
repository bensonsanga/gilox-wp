
                  <h3 class="card-pantheon__description">

<a class="card-pantheon__button" href="<?php echo get_permalink();?>" data-video-gallery-card-heading="">
<?php echo the_title(); ?> </a>
</h3><!-- .c-card__heading -->


<span class="c-card__tag t-semibold t-semibold--upper t-semibold--loose" data-video-gallery-card-tag="">

<?php echo the_title(); ?> 
</span>


<p class="c-card__lead t-copy" data-video-gallery-card-lead="">
"I want everyone in this painting — particularly the African American women and children — to know that they matter," artist says </p><!-- /.c-card__lead t-copy -->
