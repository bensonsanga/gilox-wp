Gilox is a wordpress site buildt to run on loal server but meant to launch soon at 
https://gilox.co/

Go to wp-admin and change 